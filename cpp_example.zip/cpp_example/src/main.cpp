#include <iostream>
#include <memory>

#include "planary/rectangle.h"
#include "units/wiffle.h"

/*
 * Často můžete na internetových příkladech vidět následujicí linku, která vám ušetří psaní std::, ps:: a uts:: v dalším
 * kódu. Prosím Vás nedělejte to! Mohou totiž vznikat konflikty ve jmenných prostorech. Třeba úplně primitivní vector...
 * pokud budete užívat vector knihovny STL, a pak budete na něco potřebovat knihovnu Boost nebo OpenCV -- Vaše jistota,
 * že používáte právě std::vector je rázem pryč.
 */
//using namespace std; // fuj...

/*!
 * \brief CONSTANT Takto se dělá konstanta v C++. Dokázali byste říci, co je na tomto řešení
 *                 lepší oproti klasickým preprocesorovým konstantám?
 */
constexpr double CONSTANT = 1.0;

/*!
 * \brief main U funkce main si všimněte, že nejsou uvedeny žádné parametry a není zde žádný return. Ještě zajímavější je,
 *             že kompilátor na to nic neříká.
 */
int main() {
    uts::Wiffle a = CONSTANT;

    // Objekt vytvořený klasicky na stacku.
    ps::Rectangle<uts::Wiffle> stack_rect(a, a);
    std::cout << "Obvod obdelniku na stacku je " << stack_rect.perimeter() << "." << std::endl;
    std::cout << "Obsah obdelniku na stacku je " << stack_rect.area() << "^2." << std::endl;

    // Tohle znáte z KIV/PC (akorát trošku kamuflovaně).
    ps::Rectangle<uts::Wiffle>* ptr_rect = new ps::Rectangle<uts::Wiffle>(2.0, 2.0);
    std::cout << "Obvod obdelniku (ptr) je " << ptr_rect->perimeter() << "." << std::endl;
    std::cout << "Obsah obdelniku (ptr) je " << ptr_rect->area() << "^2." << std::endl;

    {
        // Tady už je to zajímavější (viz example na https://doc.qt.io/qt-5/qscopedpointer.html)
        std::unique_ptr<ps::Rectangle<uts::Wiffle>> unique_rect = std::make_unique<ps::Rectangle<uts::Wiffle>>(3.0, 3.0);
        if (unique_rect)    // Jak je možné, že můžu udělat tohle?
            std::cout << "Objekt unique_rect byl uspesne dynamicky alokovan!" << std::endl;

        std::cout << "Obvod obdelniku (unique_ptr) je " << unique_rect->perimeter() << "." << std::endl;
        std::cout << "Obsah obdelniku (unique_ptr) je " << unique_rect->area() << "^2." << std::endl;
    }

    // Jak funguje shared pointer: https://blog.scrt.ch/wp-content/uploads/2017/01/shared_ptr.png
    std::shared_ptr<ps::Rectangle<uts::Wiffle>> backup_ptr;

    {
        // Pokud vás už nebaví psát ty typy (mě to baví), tak můžete využít autodedukce typu pomocí auto.
        auto shared_rect = std::make_shared<ps::Rectangle<uts::Wiffle>>(4.0, 4.0);
        //std::cout << shared_rect.use_count() << std::endl;
        backup_ptr = shared_rect;
        std::cout << "Obvod obdelniku (shared_ptr) je " << shared_rect->perimeter() << "." << std::endl;
        std::cout << "Obsah obdelniku (shared_ptr) je " << shared_rect->area() << "^2." << std::endl;
    }

    std::cout << "Opustil jsem scope, ale shared pointer stale zije! ...proc asi." << std::endl;

    // Je takto zdrojový kód v pořádku?
}
