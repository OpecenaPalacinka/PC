#pragma once

#include "planary.h"

namespace ps {

/**
* \brief Třída Rectangle
*
* Představuje úplně obyčejný obdelník zadaný délkami stran.
*/
template <class T>
class Rectangle : public IPlanary<T> {
public:
    /**
    * \brief Rectangle Konstruktor třídy. Všimněte se initializer listu v C++.
    * \param a Rozměr strany a.
    * \param b Rozměr strany b.
    */
    explicit Rectangle(T a, T b) : m_a(a), m_b(b) {
        std::cout << "Konstrukce objektu tridy Rectangle(" << m_a << ", " << m_b << ")." << std::endl;
    }

    /**
    * \brief ~Rectangle Destruktor třídy.
    */
    virtual ~Rectangle() override {
        std::cout << "Destrukce objektu tridy Rectangle(" << m_a << ", " << m_b << ")." << std::endl;
    }

    /**
     * \brief Getter, který vrací délku strany a.
     * \return const T& Délka strany a.
     */
    const T& a() const {
        return m_a;
    }

    /**
     * \brief Getter, který vrací délku strany b.
     * \return const T& Délka strany b.
     */
    const T& b() const {
        return m_b;
    }

    /**
     * \brief Metoda vrací obvod obdelníku. 
     * \return T Obvod obdelníku.
     */
    virtual T perimeter() const override final {
        return (m_a + m_b) * T(2);
    }

    /**
     * \brief Metoda, která vypočítá obsah plochy.
     * \return T Obsah plochy obdelníku.
     */
    virtual T area() const override final {
        return m_a * m_b;
    }

private:
    T m_a;     //!< Délka strany a.
    T m_b;     //!< Délka strany b.
};

}