#pragma once

namespace ps {

/**
 * \brief Třída IPlanary
 *
 * C++ nezná pojem "rozhraní". Tato třída obsahuje pouze deklarace čistě virutálních tříd
 * (pure virtual). Pokud se pokusíme vytvořit objekt této třidy, tak překlad skončí chybou
 * protože kompilátor nenalezne definice členských funkcí (metod).
 */
template <class T>
class IPlanary {
public:
    /**
     * \brief Pokud třída obsahuje virtuální metody, tak musí obsahovat i virtuální destruktor.
     *        O vysvětlení si řekněte cvičícímu.
     */
    virtual ~IPlanary() = default;

    /**
     * \brief perimeter Vypočítá obvod planární oblasti.
     * \return Obvod planární oblasti.
     */
    virtual T perimeter() const = 0;

    /*!
     * \brief area Vypočítá obsah rovinné oblasti.
     * \return Obsa planární oblasti.
     */
    virtual T area() const = 0;
};

}
