#pragma once

#include <iostream>

namespace uts {
    
/**
 * \brief Třída Wiffle
 *
 * Délková jednotka odpovídající 89 mm. Jedná se o průměr míčku ke hře Wiffleball.
 * Další info zde (https://en.wikipedia.org/wiki/List_of_humorous_units_of_measurement#Wiffle).
 */
class Wiffle {
public:
    /**
     * \brief Wiffle Bezparametrový konstruktor nastaví hodnotu na 0.
     */
    Wiffle();

    /**
     * \brief Wiffle Konstruktor třídy. Všimněte si, že slovo "explicit" není uvedeno.
     * \param u Rozměr ve Wifflech.
     */
    Wiffle(double u);

    /**
     * \brief operator double Přetížení operátoru přetypování na double.
     */
    operator double() const;

    /**
     * \brief operator + Přetížení operátoru sčítání.
     * \param b Druhý sčítanec.
     * \return Výsledný součet.
     */
    Wiffle operator+(const Wiffle& b) const;

    /**
     * \brief operator * Přetížení operátoru násobení.
     * \param b Druhý činitelel při násobení.
     * \return Výsledný součin.
     */
    Wiffle operator*(const Wiffle& b) const;

    /**
     * \brief operator << Přetížení operátoru binárního posunu. Všimněte si klíčového
     *                    slova friend -- toto je sand jeho jediná smysluplná varianta
     *                    užití. Vtípek: http://home.zcu.cz/~ublm/vyuka/tsi/natural.png
     *
     *                    Pozn. Možná by klíčové slovo mělo být raději girlfriend/boyfriend.
     * \param os Datový proud, do kterého bude objekt zapsán.
     * \param w Co bude zapsáno.
     * \return Předaná reference na datový proud -- vidíte praktický význam této hodnoty?
     */
    friend std::ostream& operator<<(std::ostream& os, const Wiffle& w) {
        os << w.m_u << " Wf";
        return os;
    }

private:
    double m_u;     //!< Rozměr ve Wifflech.
};

}
