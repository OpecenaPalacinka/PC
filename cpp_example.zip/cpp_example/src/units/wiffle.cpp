#include "wiffle.h"

uts::Wiffle::Wiffle() : m_u(0.0) { }

uts::Wiffle::Wiffle(double u) : m_u(u) { }

uts::Wiffle::operator double() const {
    return m_u;
}

uts::Wiffle uts::Wiffle::operator+(const uts::Wiffle& b) const {
    Wiffle temp = *this;
    temp.m_u += b.m_u;

    return temp;
}

uts::Wiffle uts::Wiffle::operator*(const uts::Wiffle& b) const {
    Wiffle temp = *this;
    temp.m_u *= b.m_u;

    return temp;
}